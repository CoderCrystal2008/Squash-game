var ball,ballimg,paddle,paddleimg;
var topEdge,bottomEdge,leftEdge;
function preload() {
  /* preload your images here of the ball and the paddle */
  ballimg = loadAnimation("ball.png");
  paddleimg = loadAnimation("paddle.png");
}
function setup() {
  createCanvas(400, 400);
   /* create the Ball Sprite and the Paddle Sprite */
  topEdge = createSprite(390,1,750,1);
  leftEdge = createSprite(1,390,1,750);
  bottomEdge = createSprite(390,399,750,1);
  ball = createSprite(200,200,10,10);
  paddle = createSprite(390,200,10,70);
  
  //makes top,bottom and left edges invisible
  //topEdge.visible = false;
  //bottomEdge.visible = false;
  //leftEdge.visible = false;
  
  
  /* assign the images to the sprites */
  ball.addAnimation("ballimg",ballimg);
  paddle.addAnimation("paddleimg",paddleimg);
  
  
  /* give the ball an initial velocity of 9 in the X direction */
 ball.setVelocity(9,9);
  

}

function draw() {
  background(205,153,0);
  /* create Edge Sprites here */
  createEdgeSprites();
  /* Allow the ball sprite to bounceOff the left, top and bottom edges only, leaving the right edge of the canvas to be open. */
  ball.bounceOff(topEdge);
  ball.bounceOff(bottomEdge);
  ball.bounceOff(leftEdge);
  
  //makes the ball bounce off the paddle
  ball.bounceOff(paddle);
  
  

  /* Allow the ball to bounceoff from the paddle */
  /* Also assign a collision callback function, so that the ball can have a random y velocity, making the game interesting */
 
  /* Prevent the paddle from going out of the edges */ 
  
  
  if(keyWentDown(UP_ARROW))
  {
     /* what should happen when you press the UP Arrow Key */
    paddle.velocityY = -9;
  }
  
  if(keyWentUp(UP_ARROW)){
    paddle.velocityY = 0;
  }
  
  if(keyWentDown(DOWN_ARROW))
  {
    /* what should happen when you press the DOWN Arrow Key */
    paddle.velocityY = 9;
  }
  
  if(keyWentUp(DOWN_ARROW)){
    paddle.velocityY = 0;
  }
  drawSprites();
  
}

function randomVelocity()
{
  /* this function gets called when the ball bounces off the paddle */
  /* assign the ball a random vertical velocity, so it bounces off in random direction */
}

